<?php

namespace app\admin\controller\cms;

use app\admin\model\Channel;
use app\common\controller\Backend;
use fast\Tree;

/**
 * 内容表
 *
 * @icon fa fa-circle-o
 */
class Archives extends Backend
{

    /**
     * Archives模型对象
     */
    protected $model = null;
    protected $noNeedRight = ['get_channel_fields', 'check_element_available'];

    public function _initialize()
    {
        parent::_initialize();
        $this->model = model('Archives');

        $channelList = [];
        $disabledIds = [];
        $all = collection(Channel::order("weigh desc,id desc")->select())->toArray();
        foreach ($all as $k => $v)
        {
            $state = ['opened' => true];
            if ($v['type'] != 'list')
            {
                $disabledIds[] = $v['id'];
            }
            if ($v['type'] == 'link')
            {
                $state['checkbox_disabled'] = true;
            }
            $channelList[] = [
                'id'     => $v['id'],
                'parent' => $v['parent_id'] ? $v['parent_id'] : '#',
                'text'   => __($v['name']),
                'type'   => $v['type'],
                'state'  => $state
            ];
        }
        $tree = Tree::instance()->init($all, 'parent_id');
        $channelOptions = $tree->getTree(0, "<option value=@id @selected @disabled>@spacer@name</option>", '', $disabledIds);
        $this->view->assign('channelOptions', $channelOptions);
        $this->assignconfig('channelList', $channelList);

        $this->view->assign("flagList", $this->model->getFlagList());
        $this->view->assign("statusList", $this->model->getStatusList());
    }

    /**
     * 查看
     */
    public function index()
    {
        //设置过滤方法
        $this->request->filter(['strip_tags']);
        if ($this->request->isAjax())
        {
            $this->relationSearch = TRUE;
            //如果发送的来源是Selectpage，则转发到Selectpage
            if ($this->request->request('pkey_name'))
            {
                return $this->selectpage();
            }
            list($where, $sort, $order, $offset, $limit) = $this->buildparams();
            $total = $this->model
                    ->with('Channel')
                    ->where($where)
                    ->order($sort, $order)
                    ->count();

            $list = $this->model
                    ->with('Channel')
                    ->where($where)
                    ->order($sort, $order)
                    ->limit($offset, $limit)
                    ->select();

            $result = array("total" => $total, "rows" => $list);

            return json($result);
        }
        return $this->view->fetch();
    }

    /**
     * 编辑
     * 
     * @param mixed $ids
     */
    public function edit($ids = NULL)
    {
        $row = $this->model->get($ids);
        if (!$row)
            $this->error(__('No Results were found'));
        $adminIds = $this->getDataLimitAdminIds();
        if (is_array($adminIds))
        {
            if (!in_array($row[$this->dataLimitField], $adminIds))
            {
                $this->error(__('You have no permission'));
            }
        }
        if ($this->request->isPost())
        {
            return parent::edit($ids);
        }
        $channel = Channel::get($row['channel_id']);
        if (!$channel)
        {
            $this->error(__('No specified channel found'));
        }
        $model = \app\admin\model\Modelx::get($channel['model_id']);
        if (!$model)
        {
            $this->error(__('No specified model found'));
        }
        $addon = db($model['table'])->where('id', $row['id'])->find();
        if ($addon)
        {
            $row = array_merge($row->toArray(), $addon);
        }

        $all = collection(Channel::order("weigh desc,id desc")->select())->toArray();
        foreach ($all as $k => $v)
        {
            if ($v['type'] != 'list' || $v['model_id'] != $channel['model_id'])
            {
                $disabledIds[] = $v['id'];
            }
        }
        $tree = Tree::instance()->init($all, 'parent_id');
        $channelOptions = $tree->getTree(0, "<option value=@id @selected @disabled>@spacer@name</option>", $row['id'], $disabledIds);
        $this->view->assign('channelOptions', $channelOptions);
        $this->view->assign("row", $row);
        return $this->view->fetch();
    }

    /**
     * 删除
     * @param mixed $ids
     */
    public function del($ids = "")
    {
        \app\admin\model\Archives::event('after_delete', function($row) {
            Channel::where('id', $row['channel_id'])->where('items', '>', 0)->setDec('items');
        });
        return parent::del($ids);
    }

    /**
     * 还原
     * @param mixed $ids
     */
    public function restore($ids = "")
    {
        //这里无法监听到Archives的after_update事件
        \think\db\Query::event('after_update', function($options, $query) {
            if (isset($options['soft_delete']))
            {
                $channelIds = $query->column('channel_id');
                $channelNums = array_count_values($channelIds);
                foreach ($channelNums as $k => $v)
                {
                    Channel::where('id', $k)->setInc('items', $v);
                }
            }
            return;
        });
        return parent::restore($ids);
    }

    /**
     * 移动
     */
    public function move($ids = "")
    {
        if ($ids)
        {
            $channel_id = $this->request->post('channel_id');
            $pk = $this->model->getPk();
            $adminIds = $this->getDataLimitAdminIds();
            if (is_array($adminIds))
            {
                $this->model->where($this->dataLimitField, 'in', $adminIds);
            }
            $this->model->where($pk, 'in', $ids);
            $channel = Channel::get($channel_id);
            if ($channel && $channel['type'] === 'list')
            {
                $channelNums = \app\admin\model\Archives::
                        with('channel')
                        ->where('archives.' . $pk, 'in', $ids)
                        ->where('channel_id', '<>', $channel['id'])
                        ->field('channel_id,COUNT(*) AS nums')
                        ->group('channel_id')
                        ->select();
                $result = $this->model
                        ->where('model_id', '=', $channel['model_id'])
                        ->where('channel_id', '<>', $channel['id'])
                        ->update(['channel_id' => $channel_id]);
                if ($result)
                {
                    $count = 0;
                    foreach ($channelNums as $k => $v)
                    {
                        if ($v['channel'])
                        {
                            Channel::where('id', $v['channel_id'])->where('items', '>', 0)->setDec('items', min($v['channel']['items'], $v['nums']));
                        }
                        $count += $v['nums'];
                    }
                    Channel::where('id', $channel_id)->setInc('items', $count);
                    $this->success();
                }
                else
                {
                    $this->error(__('No rows were updated'));
                }
            }
            else
            {
                $this->error(__('No rows were updated'));
            }
            $this->error(__('Parameter %s can not be empty', 'ids'));
        }
    }

    /**
     * 获取栏目列表
     * @internal
     */
    public function get_channel_fields()
    {
        $this->view->engine->layout(false);
        $channel_id = $this->request->post('channel_id');
        $archives_id = $this->request->post('archives_id');
        $channel = Channel::get($channel_id, 'model');
        if ($channel && $channel['type'] === 'list')
        {

            $values = [];
            if ($archives_id)
            {
                $values = db($channel['model']['table'])->where('id', $archives_id)->find();
            }

            $fields = \app\admin\model\Fields::where('model_id', $channel['model_id'])
                    ->order('weigh desc,id desc')
                    ->select();
            foreach ($fields as $k => $v)
            {
                $v->value = isset($values[$v['name']]) ? $values[$v['name']] : '';
                $v->rule = str_replace(',', '; ', $v->rule);
                if (in_array($v->type, ['checkbox', 'lists', 'images']))
                {
                    $checked = '';
                    if ($v['minimum'] && $v['maximum'])
                        $checked = "{$v['minimum']}~{$v['maximum']}";
                    else if ($v['minimum'])
                        $checked = "{$v['minimum']}~";
                    else if ($v['maximum'])
                        $checked = "~{$v['maximum']}";
                    if ($checked)
                        $v->rule .= (';checked(' . $checked . ')');
                }
                if (in_array($v->type, ['checkbox', 'radio']) && stripos($v->rule, 'required') !== false)
                {
                    $v->rule = str_replace('required', 'checked', $v->rule);
                }
                if (in_array($v->type, ['selects']))
                {
                    $v->extend .= (' ' . 'data-max-options="' . $v['maximum'] . '"');
                }
            }

            $this->view->assign('fields', $fields);
            $this->view->assign('values', $values);
            $this->success('', null, ['html' => $this->view->fetch('fields')]);
        }
        else
        {
            $this->error(__('Please select channel'));
        }
        $this->error(__('Parameter %s can not be empty', 'ids'));
    }

    /**
     * 检测元素是否可用
     * @internal
     */
    public function check_element_available()
    {
        $id = $this->request->request('id');
        $name = $this->request->request('name');
        $value = $this->request->request('value');
        $name = substr($name, 4, -1);
        if (!$name)
        {
            $this->error(__('Parameter %s can not be empty', 'name'));
        }
        if ($id)
        {
            $this->model->where('id', '<>', $id);
        }
        $exist = $this->model->where($name, $value)->find();
        if ($exist)
        {
            $this->error(__('The data already exist'));
        }
        else
        {
            $this->success();
        }
    }

}
