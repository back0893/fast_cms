<?php

return [
    'Id'         => 'ID',
    'Type'       => '类型',
    'Archives'   => '文档',
    'Page'       => '单页',
    'Aid'        => '关联ID',
    'Pid'        => '父ID',
    'Username'   => '用户名',
    'Email'      => '邮箱',
    'Website'    => '网址',
    'Content'    => '内容',
    'Comments'   => '评论数',
    'Ip'         => 'IP',
    'Useragent'  => 'User Agent',
    'Subscribe'  => '订阅',
    'Createtime' => '创建时间',
    'Updatetime' => '更新时间',
    'Status'     => '状态'
];
