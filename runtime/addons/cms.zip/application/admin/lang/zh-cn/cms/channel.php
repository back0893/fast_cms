<?php

return [
    'Type'                   => '类型',
    'Model_id'               => '模型ID',
    'Model_name'             => '模型名称',
    'Parent_id'              => '父ID',
    'Parent_ids'             => '父ID集合',
    'Child_ids'              => '子ID集合',
    'Name'                   => '名称',
    'Image'                  => '图片',
    'Keywords'               => '关键字',
    'Description'            => '描述',
    'Diyname'                => '自定义名称',
    'Outlink'                => '外部链接',
    'Items'                  => '文章数量',
    'Weigh'                  => '权重',
    'Channeltpl'             => '栏目页模板',
    'Listtpl'                => '列表页模板',
    'Showtpl'                => '详情页模板',
    'Pagesize'               => '分页大小',
    'Createtime'             => '创建时间',
    'Updatetime'             => '更新时间',
    'The data already exist' => '已经存在',
    'Status'                 => '状态',
    'Channel'                => '栏目',
    'List'                   => '列表',
    'Link'                   => '外部链接'
];
